class Results:
      def __init__(self, players):
          self.dealer = 0
          self.player = 0
          self.pot = 0
          self.winner = ''
          self.players = players

      def dealer_won(self):
            if self.pot > 0:
                self.dealer  = self.pot + 1
                self.pot = 0
            else:
                self.dealer += 1
            self.winner = self.players["dealer"].name
            print(f'WINNER: {self.winner}')
            return

      def player_won(self):
            if self.pot > 0:
                self.player = self.pot + 1
                self.pot = 0
            else:
                self.player += 1
            self.winner = self.players["player"].name
            print(f'WINNER: {self.winner}')
            return

      def draw(self):
            self.pot += 1
            self.winner = "draw"
            print(f'WINNER: {self.winner.title()}')
            return