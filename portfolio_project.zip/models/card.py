class Card:

        def __init__(self, face, h_value, l_value):
              self.face = face
              self.value = h_value
              self.h_value = h_value
              self.l_value = l_value
              self.possible_values = (h_value, l_value)